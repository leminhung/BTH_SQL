CREATE DATABASE QuanLySinhVien_De1
USE QuanLySinhVien_De1


CREATE TABLE Khoa
(
    MaKhoa CHAR(10) NOT NULL PRIMARY KEY,
    TenKhoa NVARCHAR(50),
    DienThoai CHAR(20)
)


CREATE TABLE Lop
(
    MaLop CHAR(10) NOT NULL PRIMARY KEY,
    TenLop NVARCHAR(50),
    SiSo INT,
    MaKhoa CHAR(10),
    CONSTRAINT fk_Lop_Khoa FOREIGN KEY(MaKhoa) REFERENCES Khoa(MaKhoa)
)



CREATE TABLE SinhVien
(
    MaSV CHAR(10) NOT NULL PRIMARY KEY,
    HoTen NVARCHAR(50),
    NgaySinh DATETIME,
    DiaChi NVARCHAR(50),
    MaLop CHAR(10),
    CONSTRAINT fk_SinhVien_Lop FOREIGN KEY(MaLop) REFERENCES Lop(MaLop)
)


INSERT INTO Khoa
    VALUES  ('KH01', N'Công nghệ thông tin', '1234567'),
            ('KH02', N'Khoa học máy tính', '2345678'),
            ('KH03', N'Kĩ thuật phần mềm', '3456789')
            
        

INSERT INTO Lop
    VALUES  ('LH01', N'CNTT2', 70, 'KH01'),
            ('LH02', N'KHMT2', 60, 'KH02'),
            ('LH03', N'KTPM2', 50, 'KH03')
            
            

INSERT INTO SinhVien
    VALUES  ('SV01', N'Lê Minh Hưng', '01/02/2001', N'Thanh Hóa', 'LH01'),
            ('SV02', N'Vũ Thiên Lý', '02/03/2001', N'Hà Nam', 'LH02'),
            ('SV03', N'Hoàng Đăng Dương', '03/04/2001', N'Bắc Giang', 'LH03'),
            ('SV04', N'Nguyễn Phương Nam', '04/05/2001', N'Phú Yên', 'LH01'),
            ('SV05', N'Nguyễn Khắc Nguyên', '05/06/2001', N'Hà Nội', 'LH02')



SELECT * FROM Khoa
SELECT * FROM Lop
SELECT * FROM SinhVien



--2
CREATE FUNCTION Cau2(@TenKhoa NVARCHAR(50), @TenLop NVARCHAR(50))
RETURNS @bang2 TABLE(MaSV CHAR(10), HoTen NVARCHAR(50), Tuoi INT)
AS
BEGIN
    INSERT INTO @bang2
    SELECT MaSV, HoTen, YEAR(NgaySinh)
    FROM Lop x JOIN Khoa y ON x.MaKhoa = y.MaKhoa
                JOIN SinhVien z ON x.MaLop = z.MaLop
    WHERE TenKhoa = @TenKhoa AND TenLop = @TenLop
    RETURN
END

-- TH1: Nhập hợp lệ
SELECT * FROM dbo.Cau2(N'Công nghệ thông tin', N'CNTT2')

-- TH2: Nhập sai tên khoa
SELECT * FROM dbo.Cau2(N'Công nghệ thôngggg tin', N'CNTT2')

-- TH3: Nhập sai tên lớp
SELECT * FROM dbo.Cau2(N'Công nghệ thông tin', N'CNTT9')



-- 3

CREATE PROC sp_TimKiem(@TuTuoi INT, @DenTuoi INT)
AS
BEGIN
    IF NOT EXISTS(SELECT * FROM SinhVien WHERE YEAR(NgaySinh) > @DenTuoi OR YEAR(NgaySinh) < @TuTuoi)
        BEGIN
            RAISERROR(N'Không tìm thấy sinh viên nào', 16, 1)
            RETURN
        END
END